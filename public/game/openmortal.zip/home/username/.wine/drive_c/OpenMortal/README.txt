OpenMortal 0.7 README

OpenMortal is a spoof of the original Mortal Kombat fighting game. The
funny thing about OpenMortal is that you can play the game AS YOURSELF.
It takes some work, but if you follow the Character Creation-HOWTO at

http://openmortal.sourceforge.net/Character_HOWTO.html

OpenMortal is still under development. The most important missing
features are:
* There is no support single player game.
* Throws are missing.
* Most of the projectiles aren't implemented yet.

Other planned features:
* Downloadable characters.

For further details, see the project's bug and feature request databases.

USAGE:

Press Esc key to bring up the main menu.
You can skip most scenes (such as instant replays) with the F1 key.
The default keys are:
         Player 1        Player 2
Up       Cursor up       W
Down     Cursor down     S
Left     Cursor left     A
Right    Cursor right    D
HPunch   Insert          R
LPunch   Delete          F
HKick    Home            T
LKick    End             G
Block    PgDown          H

Combinations:

Up + Left: Jump to the left. Hit Kick or Punch for a jumpkick/punch.
Up + Right: Jump to the right. Hit Kick or Punch for a jumpkick/punch.
Back + HKick/HPunch: Spinning attack (depends on character)
Back + LKick: Leg sweep
Forward + LKick: Knee attack
Down, HPunch: Uppercut
Forward, Back + LKick: Groin kick (ouch!)

Plus, each character has a number of special attacks.. experiment to find
them, or read them at the character screen.

The length of rounds and strength of characters can be changed in the menu.


NETWORK PLAY:

You can set up the connection yourself, or go to MortalNet to find opponents.
Setting up is relatively simple: one player needs to Create a game, the other
has to Join, by enterin the other player's IP address or hostname in the
network menu. When both players choose "Start network game", the connection
is established.

OpenMortal needs port 14882/TCP to be available on the game creator's side.

MortalNet (also available in the Network menu) automates the creation / join
process.

The network play is still experimental, if you experience problems, please
report them on the project's homepage.


PACKAGERS:

It is possible to split OpenMortal into sub-packages, separating characters
from the base package, and thus reduce download times.
